new DataTable('#example', {
    responsive: true
});